#!/bin/bash

# Update the system
sudo apt update