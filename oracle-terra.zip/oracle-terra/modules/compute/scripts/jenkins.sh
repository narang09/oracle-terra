#!/bin/bash

# Update the system
sudo apt update

# Install Java Development Kit (JDK)
sudo apt install -y openjdk-11-jdk

# Download and install Jenkins
wget -O ~/jenkins.deb https://pkg.jenkins.io/debian-stable/binary/jenkins_2.303.3_all.deb       # Modify the Jenkins version if needed
sudo dpkg -i ~/jenkins.deb

# Install dependencies (if needed)
sudo apt --fix-broken install -y

# Start Jenkins service
sudo systemctl start jenkins

# Enable Jenkins service to start on boot
sudo systemctl enable jenkins

# Print initial Jenkins admin password
echo "Jenkins initial admin password:"
sudo cat /var/lib/jenkins/secrets/initialAdminPassword

sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 8080 -j ACCEPT
sudo netfilter-persistent save
